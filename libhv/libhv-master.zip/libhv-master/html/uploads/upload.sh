bin/curl -v localhost:8080/upload -F "file=@LICENSE"
